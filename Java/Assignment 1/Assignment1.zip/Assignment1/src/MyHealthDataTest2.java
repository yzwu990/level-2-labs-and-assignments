import java.time.LocalDate;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

/**
 * <p>
 * <b>File name:</b> MyHealthDataTest2.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 * <p>
 * <b>Assignment:</b> Assignment 1
 * </p>
 * 
 * <p>
 * <b>Date:</b> Nov 2, 2022
 * </p>
 * 
 * <p>
 * <b>Professor:</b> Fedor Ilitchev
 * </p>
 * 
 *  <hr>
 * 
 * <p>
 * <b>Purpose:</b> This is a JUnit test class used to test
 * MyHealthData.java for assignment 1.
 *  </p>
 * <hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 */

public class MyHealthDataTest2 {

	/* EPSILON is used to verify the difference between the expected value and the
	*  return value.
	*/
	private static final double EPSILON = 0.01;

	/**
	*	This is the entry point for the test application.
	*/
	@Test
	public void test() {

		// Initiation
		String firstName = "Yz";
		String lastName = "Wu";
		String gender = "M";
		double height = 71;
		double weight = 154;
		int birthYear = 1990;
		int currentYear = LocalDate.now().getYear();

		MyHealthData testData = new MyHealthData(firstName, lastName, gender, height, weight, birthYear, currentYear);
		
		// The expected value is calculated manually.
		// BMI = weight * 703 / (height * height)
		// BMI = 154 * 703/(154 * 154)
		double expected = 21.47;
		
		Assert.assertEquals(expected, testData.getBMI(), EPSILON);

	}

}
