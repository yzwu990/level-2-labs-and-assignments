import java.time.LocalDate;
import java.util.Scanner;

/**
 * <p>
 * <b>File name:</b> MyHealthDataTest.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 * <p>
 * <b>Assignment:</b> Assignment 1
 * </p>
 * 
 * <p>
 * <b>Date:</b> Nov 2, 2022
 * </p>
 * 
 * <p>
 * <b>Professor:</b> Fedor Ilitchev
 * </p>
 * 
 * <hr>
 * 
 *  <p>
 *  <b>Purpose:</b> This program is used to test MyHealthData.java for
 *  assignment 1. It asks for user's inputs and output patient's
 *  information.
 *  </p>
 * 
 *  <hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 */

public class MyHealthDataTest {

	/**
	 * 
	 * This is the entry point for the application. It prompts for input of the
	 * patient’s data, and instantiates an object of the class MyHealthData for that
	 * patient and then prints the data from that object. 
	 * 
	 * @param args Command line arguments are not used by this program.
	 */
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter first name:");
		String firstName = input.nextLine();
		
		System.out.println("Please enter last name:");
		String lastName = input.nextLine();
		
		System.out.println("Please enter gender:");
		String gender = input.nextLine();
		
		System.out.println("Please enter height in inches:");
		double height = input.nextDouble();
		input.nextLine();
		
		System.out.println("Please enter weight in pounds:");
		double weight = input.nextDouble();
		input.nextLine();
		
		System.out.println("Please enter year of birth:");
		int birthYear = input.nextInt();
		input.nextLine();
		
		// Use localDate API to get current year
		int currentYear = LocalDate.now().getYear();
		
		
		MyHealthData data=new MyHealthData(firstName, lastName, gender, height, weight, birthYear, currentYear);
		
		data.displayMyHealthData();
		
		
		
		
		

	}

}
