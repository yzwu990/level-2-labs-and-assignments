/**
 * <p>
 * <b>File name:</b> MyHealthData.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 * <p>
 * <b>Assignment:</b> Assignment 1
 * </p>
 * 
 * <p>
 * <b>Date:</b> Nov 2, 2022
 * </p>
 * 
 * <p>
 * <b>Professor:</b> Fedor Ilitchev
 * </p>
 * 
 * <hr>
 * 
 * <p>
 * <b>Purpose:</b> This is an Electronic Health Records (EHR) system. It is used for patients' first visit 
 * to hospital.
 * It records and outputs patients' first name, last name, gender, year of birth, current year, height, weight, 
 * age, BMI, maximum heart rate, and target heart rate range.
 * </p>       
 *  <hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 */


public class MyHealthData{

	// These variables are patients information
	private String firstName;
	private String lastName;
	private String gender;
	private int birthYear;
	private int currentYear;
	private double height;
	private double weight;
		
	
	
	/**
	 * Constructor sets firstName, lastName, gender, height, weight, birthYear, currentYear
	 * @param firstName The first name of the patient
	 * @param lastName The last name of the patient
	 * @param gender The gender of the patient
	 * @param height The height of the patient
	 * @param weight The weight of the patient
	 * @param birthYear The birth year of the patient
	 * @param currentYear The current year
	 */
	public MyHealthData(String firstName, String lastName, String gender, double height, double weight, int birthYear,
			int currentYear) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.height = height;
		this.weight = weight;
		this.birthYear = birthYear;
		this.currentYear = currentYear;
	}
	

	/**
	 * Returns The first name of the patient.
	 * @return The first name of the patient.
	 */
	public String getFirstName() {
		return firstName;
	}

	
	/**
	 * Sets The first name of the patient.
	 * @param firstName The first name of the patient.
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/**
	 * Returns The last name of the patient.
	 * @return The last name of the patient.
	 */
	public String getLastName() {
		return lastName;
	}


	/**
	 * Sets The last name of the patient.
	 * @param lastName The last name of the patient.
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	

	/**
	 * Returns The gender of the patient.
	 * @return The gender of the patient.
	 */
	public String getGender() {
		return gender;
	}

	
	/**
	 * Sets The gender of the patient.
	 * @param gender The gender of the patient.
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	
	/**
	 * Returns The birth year of the patient.
	 * @return The birth year of the patient.
	 */
	public int getBirthYear() {
		return birthYear;
	}


	/**
	 * Sets The birth year of the patient.
	 * @param birthYear The birth year of the patient.
	 */
	public void setBirthYear(int birthYear) {
		this.birthYear = birthYear;
	}


	/**
	 * Returns The current year.
	 * @return The current year.
	 */
	public int getCurrentYear() {
		return currentYear;
	}


	/**
	 * Sets The current year.
	 * @param currentYear The current year.
	 */
	public void setCurrentYear(int currentYear) {
		this.currentYear = currentYear;
	}


	/**
	 * Returns The height of the patient.
	 * @return The height of the patient.
	 */
	public double getHeight() {
		return height;
	}


	/**
	 * Sets The height of the patient.
	 * @param height The height of the patient.
	 */
	public void setHeight(double height) {
		this.height = height;
	}


	/**
	 * Returns The weight of the patient.
	 * @return The weight of the patient.
	 */
	public double getWeight() {
		return weight;
	}

	
	/**
	 * Sets The weight of the patient.
	 * @param weight The weight of the patient.
	 */
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	
	/**
	 * Returns The age of the patient.
	 * @return The age of the patient.
	 */
	public int getAge() {
		return currentYear-birthYear;
	}
	
	
	/**
	 * Returns The maximum heart rate of the patient.
	 * @return The maximum heart rate of the patient.
	 */
	public int getMaximumHeartRate() {
		return 220-getAge();
	}
	
	
	/**
	 * Returns The minimum target heart rate of the patient.
	 * @return The minimum target heart rate of the patient.
	 */
	public double getMinimumTargetHeartRate() {
		return 0.5*getMaximumHeartRate();
	}
	
	
	/**
	 * Returns The maximum target heart rate of the patient.
	 * @return The maximum target heart rate of the patient.
	 */
	public double getMaximumTargetHeartRate() {
		return 0.85*getMaximumHeartRate();
	}
	

	/**
	 * Returns The BMI of the patient.
	 * @return The BMI of the patient.
	 */
public double getBMI() {
   return (getWeight() * 703) / (getHeight() * getHeight());
} 




/**
 * Display patient's information.
 */
public void displayMyHealthData() 
{ 

	System.out.printf("%s%s\n","First name: ", firstName);
	System.out.printf("%s%s\n","Last name: ",lastName);
	System.out.printf("%s%s\n","Gender: ",gender);
	System.out.printf("%s%d\n","Year of birth: ", birthYear);
	System.out.printf("%s%.2f\n","Height: ", height);
	System.out.printf("%s%.2f\n","Weight: ", weight);
	System.out.printf("%s%d\n","Age: ", getAge());
	System.out.printf("%s%.1f\n","BMI: ",getBMI());
	System.out.printf("%s%d\n","maximum heart rate: ", getMaximumHeartRate());
	System.out.printf("%s%.2f%s%.2f\n","Target heart rate range: ", getMinimumTargetHeartRate()," - ",getMaximumTargetHeartRate());
	
	System.out.println("BMI VALUES");
	System.out.println("Underweight: less than 18.5");
	System.out.println("Normal:      between 18.5 and 24.9");
	System.out.println("Overweight:  between 25 and 29.9");
	System.out.println("Obese:       30 or greater");   
} 

} // end class MyHealthData


