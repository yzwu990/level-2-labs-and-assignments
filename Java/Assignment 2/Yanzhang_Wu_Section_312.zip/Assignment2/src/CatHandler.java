/**
 * <p>
 * <b>File name:</b> CatHandler.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Assignment 2
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 25, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is CatHandler. It creates some exceptions and catches them.
 * Within this CatHandler class, there are ExceptionAlpha, ExceptionBeta
 * and ExceptionGammer as inner classes.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class CatHandler {
	/**
	 * This is the entry point for the application. It creates a CatHandler object cat,
	 * and throws and catches the exceptions from its inner classes.
	 * 
	 * @param args Command line arguments are not used by this program.
	 *
	 */
	public static void main(String[] args) {
		
		// Create new CatHandler 
		CatHandler cat = new CatHandler();
		
		// throw ExceptionBeta and catch it as ExceptionAlpha
		try {
			throw cat.new ExceptionBeta();

		} catch (ExceptionAlpha e) {
			System.out.println("ExceptionBeta has been thrown.");
			System.out.println("ExceptionAlpha is catched.");
			e.printStackTrace();
		}
		
		// throw ExceptionGammer and catch it as ExceptionAlpha
		try {
			throw cat.new ExceptionGammer();	
		} catch (ExceptionAlpha e) {
			System.out.println("ExceptionGammer has been thrown.");
			System.out.println("ExceptionAlpha is catched.");
			e.printStackTrace();
		}
	

	}
	
	/**
	 * inner class ExceptionAlpha extends Exception
	 * */ 
	public class ExceptionAlpha extends Exception{
		
	}
	
	/**
	 * inner class ExceptionBeta extends ExceptionAlpha
	 * */ 
	public class ExceptionBeta extends ExceptionAlpha{

	}
	
	/** 
	 * inner class ExceptionGammer extends ExceptionBeta
	 * */ 
	public class ExceptionGammer extends ExceptionBeta{
		
	}

}
