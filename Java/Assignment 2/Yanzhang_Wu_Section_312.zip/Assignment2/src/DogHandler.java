import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
/**
 * <p>
 * <b>File name:</b> DogHandler.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Assignment 2
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 25, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
  *<b>Purpose:</b> This class is DogHandler. It creates some exceptions and catches them.
 * Within this DogHandler class, there are ExceptionDog, ExceptionPuppy as inner classes.
 * The main method calls catchExceptionDog(), catchExceptionPuppy(),
 * catchNullPointerException(), and catchIOException() to test try catch block.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class DogHandler {
	/**
	 * This is the entry point for the application. It creates a DogHandler object dog,
	 * and call functions to throw and catch the exceptions.
	 * 
	 * @param args Command line arguments are not used by this program.
	 *
	 */


	public static void main(String[] args) {


		DogHandler dog = new DogHandler();
		dog.catchExceptionDog();
		dog.catchExceptionPuppy();
		dog.catchNullPointerException();
		dog.catchIOException();
		
		
	}
	
	/**
	 * This method throws and catches ExceptionDog
	 * */
	public void catchExceptionDog() {
		
		try {
			throw new ExceptionDog();
			
		} catch (ExceptionDog e) {
			System.out.println("Caught the exception");  
			e.printStackTrace();  
		}
	}
	
	
	/**
	 * This method throws and catches ExceptionPuppy
	 * */
	public void catchExceptionPuppy() {
		try {
			throw new ExceptionPuppy();
		} catch (ExceptionPuppy e) {
			System.out.println("Caught the exception");  
			e.printStackTrace();  
		}
	}
	
	
	/**
	 * This method throws and catches NullPointerException
	 * */
	public void catchNullPointerException() {
		try {
			String s = null;
		    System.out.println( s.toString() ); 
		} catch (NullPointerException npe) {
			System.out.println("Caught the NullPointerException"); 
			npe.printStackTrace();
		}
	}
	
	
	/**
	 * This method throws and catches IOException
	 * */
	public void catchIOException() {
		try {
			File fileName = new File("java.txt");
			FileInputStream fis = new FileInputStream(fileName);

		} catch (IOException ioe) {
			System.out.println("Caught the IOException"); 
			ioe.printStackTrace();
		}
	}
	
	
	/**
	 * inner class ExceptionGammer extends Exception
	 * */ 
	public class ExceptionDog extends Exception{
		
	}
	
	/**
	 * inner class ExceptionPuppy extends ExceptionDog
	 * */ 
	public class ExceptionPuppy extends ExceptionDog{
		
	}
	
}
