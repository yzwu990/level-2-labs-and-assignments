import java.io.IOException;
/**
 * <p>
 * <b>File name:</b> FishHandler.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Assignment 2
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 25, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is OrderHandler. It is used to test the 
 * arrangement (order) of the catch blocks
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class OrderHandler {
	/**
	 * This is the entry point for the FishHandler. It creates a IOException object ioe,
	 * and throws it, cathes the subclass exception and superclass exception in the right order .
	 * 
	 * @param args Command line arguments are not used by this program.
	 *
	 */
	public static void main(String[] args) {

		IOException ioe = new IOException();
		
/*
 * Codes below is the example of wrong orders, it will create compilation error
 * */
			
//		try {
//			throw ioe;
//		}catch (Exception e) {
//			e.printStackTrace();
//		}catch (IOException IOE) {
//			IOE.printStackTrace();
//		}
//		
	
/*
 * End of example of wrong orders
 * */		
		
	
		
		// this is the right order to catch exceptions
		try {
			throw ioe;
		}catch (IOException IOE) {
			IOE.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
