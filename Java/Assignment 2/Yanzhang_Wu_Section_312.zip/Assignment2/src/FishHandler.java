/**
 * <p>
 * <b>File name:</b> FishHandler.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Assignment 2
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 25, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
  *<b>Purpose:</b> This class is FishHandler. It creates some exceptions and catches them.
 * The main method calls easterStarting(). easterStarting() calls easterEnding(), catches
 * the exception and rethrow it. The main method will catch the rethrown exception.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */
public class FishHandler {
	/**
	 * This is the entry point for the FishHandler. It creates a FishHandler object fish,
	 * and call functions to throw and catch the exceptions.
	 * 
	 * @param args Command line arguments are not used by this program.
	 *
	 */
	public static void main(String[] args) {
		
		FishHandler fish = new FishHandler();
		
		try {
			fish.easterStarting();
		} catch (Exception e) {
			System.out.println("Caught the rethrow Exception" ); 
			e.printStackTrace();
		}

	}

	/**
	 * This method throws the Exception
	 * @throws Exception exception from easterEnding()
	 * */
	public void easterEnding() throws Exception{
		System.out.println("This is easterEnding(). I throw a new Exception");
		throw new Exception();
	}
	
	/**
	 * This method calls easterEnding(), catches the exception and rethrows it 
	 * @throws Exception exception from easterStarting()
	 * */
	public void easterStarting() throws Exception {
		try {
			easterEnding();
		} catch (Exception e) {
			System.out.println("This is easterStarting(). I catch Exception from easterEnding()");
			System.out.println("I rethrow the Exception." ); 
			e.printStackTrace();
			throw new Exception();
		}
	}
	
}
