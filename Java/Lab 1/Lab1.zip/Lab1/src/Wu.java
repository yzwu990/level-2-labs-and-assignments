
import java.util.Calendar;
import java.util.Scanner;

/**
 * <p>
 * <b>File name:</b> Wu.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 *         <p>
 *         <b>Class:</b> CST8284 Section 312
 *         </p>
 * 
 *         <p>
 *         <b>Assignment:</b> Lab 1
 *         </p>
 * 
 *         <p>
 *         <b>Date:</b> Sept 11, 2022
 *         </p>
 * 
 *         <p>
 *         <b>Professor:</b> Fedor Ilitchev
 *         </p>
 * 
 *         <hr>
 * 
 *         <p>
 *         <b>Purpose:</b> This program asks user to input name, student number,
 *         and two reasons of taking course CST8284. Then the program prints the
 *         information entered.
 *         <p>
 *         If the student number is odd, the program compute and outputs the
 *         remaining weeks till the end of the program and subtract 1 from the
 *         result.
 *         </p>
 *         <p>
 *         If the student number is even, the program compute and outputs
 *         Compute the number of the remaining months in the year 2022 and add 1
 *         to the result.
 *         </p>
 * 
 * @since 17.0.4.1
 * @version 1.0
 */

public class Wu {
	/**
	 * This method asks user to input name, student number, and two reasons of
	 * taking course CST8284. Then the program prints the information entered.
	 * <p>
	 * If the student number is odd, the program compute and outputs the remaining
	 * weeks till the end of the program and subtract 1 from the result.
	 * </p>
	 * <p>
	 * If the student number is even, the program compute and outputs Compute the
	 * number of the remaining months in the year 2022 and add 1 to the result.
	 * </p>
	 * 
	 * @param args arguments passed from command line
	 */
	public static void main(String[] args) {

		/* initiation and declaration */
		String name = inputName();
		String studentNumber = inputStudentNumber();
		String reason1 = inputReason();
		String reason2 = inputReason();

		/* print the entered information */
		printName(name);
		printStudentNumber(studentNumber);
		printReason(reason1);
		printReason(reason2);

		/* finish the task depending on the student number */
		task(studentNumber);

	}

	/**
	 * This method outputs "Please enter name:", then call enterInfo() method.
	 * 
	 * @return the name that user entered.
	 */
	public static String inputName() {
		System.out.println("Please enter name:");
		String name = enterInfo();
		return name;
	}

	/**
	 * This method outputs "Please enter student number:", then call enterInfo()
	 * method.
	 * 
	 * @return the student number that user entered.
	 */
	public static String inputStudentNumber() {
		System.out.println("Please enter student number:");
		String studentNumber = enterInfo();
		return studentNumber;
	}

	/**
	 * This method outputs "Please enter one reason for the course:", then call
	 * enterInfo() method.
	 * 
	 * @return the reason that user entered.
	 */
	public static String inputReason() {
		System.out.println("Please enter one reason for the course:");
		String reason = enterInfo();
		return reason;
	}

	/**
	 * This method is used to collect user's input
	 * 
	 * @return the information that user entered.
	 */
	public static String enterInfo() {
		Scanner input = new Scanner(System.in);
		/* the input data type is String */
		String info = input.nextLine();
		return info;
	}

	/**
	 * This method is used to print name
	 * 
	 * @param name the name entered by user from inputName()
	 */
	public static void printName(String name) {
		System.out.println("Student name: " + name);
	}

	/**
	 * This method is used to print student number
	 * 
	 * @param studentNumber the student number entered by user from
	 *                      inputStudentNumber()
	 *
	 */
	public static void printStudentNumber(String studentNumber) {
		System.out.println("Student number: " + studentNumber);
	}

	/**
	 * This method is used to print the reason
	 * 
	 * @param reason the reason entered by user from inputReason()
	 *
	 */
	public static void printReason(String reason) {
		System.out.println("One of the reasons: " + reason);
	}

	/**
	 * This method is used to accomplish the task required by the professor.
	 * <p>
	 * If the student number is odd, the program compute and outputs the remaining
	 * weeks till the end of the program and subtract 1 from the result.
	 * </p>
	 * <p>
	 * If the student number is even, the program compute and outputs Compute the
	 * number of the remaining months in the year 2022 and add 1 to the result.
	 * </p>
	 * 
	 * @param studentNumber the student number entered by user from
	 *                      inputStudentNumber()
	 *
	 */
	public static void task(String studentNumber) {
		/* convert student number from String to integer */
		int studentNum = Integer.parseInt(studentNumber);
		/* if the student number is even, call the corresponding the method */
		if (studentNum % 2 == 0) {
			printMonth(remainingMonths());
			/* if the student number is odd, call the corresponding the method */
		} else {
			printWeeks(remainingWeeks());
		}
	}

	/**
	 * This method is used to calculate the remaining weeks
	 * 
	 * @return the calculation result of the remaining weeks.
	 */
	public static int remainingWeeks() {

		Calendar calendar1 = Calendar.getInstance();
		int currentDay = calendar1.get(Calendar.DAY_OF_YEAR);

		Calendar calendar2 = Calendar.getInstance();
		// Set program end date to be 2024-6-30
		// Note: the month number in Calendar.set() is from 0 to 11
		calendar2.set(2024, 5, 30);
		int endDay = calendar2.get(Calendar.DAY_OF_YEAR);
		final int DAYS_IN_ONE_YEAR = 365;
		
		// step 1: remaining days of this year + days of 2023 + days to 2024.06.30
		// step 2: to calculate numbers of weeks, divide result of step 1 by 7.
		// step 3: subtract 1 from step 2
		int remainingWeeks = (DAYS_IN_ONE_YEAR - currentDay + DAYS_IN_ONE_YEAR + endDay) / 7 - 1;
		return remainingWeeks;

	}

	/**
	 * This method outputs the remaining weeks
	 * 
	 * @param remainingWeeks the calculation result of the remaining weeks from
	 *                       remainingWeeks()
	 *
	 */

	public static void printWeeks(int remainingWeeks) {
		System.out.println("The number of remaining weeks is: " + remainingWeeks);
	}

	/**
	 * This method is used to calculate the remaining months
	 * 
	 * @return the calculation result of the remaining months.
	 */

	public static int remainingMonths() {
		Calendar cal = Calendar.getInstance();
		int currentMonth = cal.get(Calendar.MONTH) + 1;
		final int LAST_MONTH = 12;
		int remainingMonths = LAST_MONTH - currentMonth + 1;
		return remainingMonths;

	}

	/**
	 * This method outputs the remaining months
	 * 
	 * @param remainingMonths the calculation result of the remaining months from
	 *                        remainingMonths()
	 *
	 */
	public static void printMonth(int remainingMonths) {
		System.out.println("The number of remaining months is: " + remainingMonths);
	}

}
