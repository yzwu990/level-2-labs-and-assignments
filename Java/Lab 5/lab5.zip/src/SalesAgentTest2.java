/**
 * <p>
 * <b>File name:</b> SalesAgentTest2.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 5
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 10, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This program is the second test for the SalesAgent class including the subclasses.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */


public class SalesAgentTest2
{  
	/**
	 * This is the entry point for the application. It creates four objects and output their string representations.
	 * 
	 * @param args Command line arguments are not used by this program.
	 */
   public static void main(String[] args)
   {
		SalesAgent agent1 = new SalesAgent("Peter",56);
		System.out.println(agent1.toString());
		
		SalesAgent agent2 = new SalesAgent("John",48);
		System.out.println(agent2.toString());
		
		
		SalesSupervisor supervisor = new SalesSupervisor("Ifeoma",53,"Toronto");
		System.out.println(supervisor.toString());
		

		SalesChief chief = new SalesChief("Yanzhang Wu",32,"Ottawa","Apparel");
		System.out.println(chief.toString());
   }
}  