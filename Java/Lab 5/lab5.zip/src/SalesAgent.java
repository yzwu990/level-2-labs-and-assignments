/**
 * <p>
 * <b>File name:</b> SalesAgent.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 5
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 10, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a SalesAgent object with name and age.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */


public class SalesAgent {

	private String name;
	private int age;


	/**
	 * Constructor without arguments
	 */
	public SalesAgent() {
		// Set name to "no name"
		this.name = "No name";
		// Set age to 0
		this.age = 0;
	}
	
	/**
	 * Construct a SalesAgent object with name and age.
	 * 
	 * @param name the name of the sales agent
	 * @param age the age of the sales agent
	 */
	public SalesAgent(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	
	/**
	 * Get the name of the sales agent
	 * 
	 * @return name of the sales agent
	 */
	public String getName() {
		return name;
	}

	
	/**
	 * Set the name of the sales agent
	 * 
	 * @param name name of the sales agent
	 */
	public void setName(String name) {
		this.name = name;
	}

	
	/**
	 * Get the age of the sales agent
	 * 
	 * @return age of the sales agent
	 */	
	public int getAge() {
		return age;
	}

	
	/**
	 * Set the age of the sales agent
	 * 
	 * @param age age of the sales agent
	 * */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * Return the string representation of the sales agent.
	 * 
	 * @return a string representation of the sales agent
	 */
	public String toString() {
		return "Sales Agent [name = " + getName() + ", age= " + getAge() + "]";
	}

}
