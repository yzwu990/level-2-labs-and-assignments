/**
 * <p>
 * <b>File name:</b> SalesAgentTest.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 5
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 10, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This program is the first test for the SalesAgent class including the subclass.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */


public class SalesAgentTest
{  
	/**
	 * This is the entry point for the application. It creates two objects and output their string representations.
	 * 
	 * @param args Command line arguments are not used by this program.
	 */
   public static void main(String[] args)
   {

		SalesAgent agent = new SalesAgent("Andrew",42);
		System.out.println(agent.toString());
		
		
		SalesSupervisor supervisor = new SalesSupervisor("James",26,"Perth");
		System.out.println(supervisor.toString());
   }
}  