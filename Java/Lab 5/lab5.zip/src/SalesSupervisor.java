/**
 * <p>
 * <b>File name:</b> SalesSupervisor.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 5
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 10, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a SalesSupervisor object with name, age, and location.
 *				  This class extends SalesAgent class.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class SalesSupervisor extends SalesAgent {

	private String location;

	/**
	 * Constructor without arguments
	 */
	public SalesSupervisor() {
		// Set location to "No location"
		this.location = "No location";
	}
	
	
	/**
	 * Construct a SalesSupervisor object with location.
	 * 
	 * @param location the location of the sales supervisor
	 */
	public SalesSupervisor(String location) {
		// Call parent class's non-argument constructor
		super();
		this.location = location;
	}
	
	/**
	 * Construct a SalesSupervisor object with name, age, and location.
	 * 
	 * @param name the name of the sales supervisor
	 * @param age the age of the sales supervisor
	 * @param location the location of the sales supervisor
	 */
	public SalesSupervisor(String name, int age,String location) {
		// Call parent class's constructor with arguments
		super(name,age);
		this.location = location;
	}
	
	
	/**
	 * Get the location of the sales supervisor
	 * 
	 * @return location of the sales supervisor
	 */
	public String getLocation() {
		return location;
	}

	
	/**
	 * Set the location of the sales supervisor
	 * 
	 * @param location location of the sales supervisor
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	
	
	
	/**
	 * Return the string representation of the sales supervisor.
	 * 
	 * @return a string representation of the sales supervisor
	 */
	@Override
	public String toString() {
		// Call parent class's toString() method
		return "Sales Supervisor [super = "+super.toString()+", location= "
				+ getLocation() + "]";

	}

}
