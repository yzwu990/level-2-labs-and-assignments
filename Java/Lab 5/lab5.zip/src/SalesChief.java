/**
 * <p>
 * <b>File name:</b> SalesChief.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 5
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 10, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a SalesChief object with name, age, location, and department.
 *				  This class extends SalesSupervisor class.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */



public class SalesChief extends SalesSupervisor {
	
	private String department;
	
	
	/**
	 * Constructor without arguments
	 */
	public SalesChief() {
		// Set department to "No department"
		this.department = "No department";
	}
	
	
	/**
	 * Construct a SalesChief object with department.
	 * 
	 * @param department the department of the sales chief
	 */
	public SalesChief(String department) {
		// Call parent class's non-argument constructor
		super();
		this.department = department;
		
	}
	
	
	/**
	 * Construct a SalesChief object with name, age, location, and department.
	 * 
	 * @param name the name of the sales chief
	 * @param age the age of the sales chief
	 * @param location the location of the sales chief
	 * @param department the department of the sales chief
	 * 
	 */
	
	public SalesChief(String name, int age,String location,String department) {
		// Call parent class's constructor with arguments
		super(name,age,location);
		this.department = department;
	}
		
	
	/**
	 * Get the department of the sales chief
	 * 
	 * @return department of the sales chief
	 */
	public String getDepartment() {
		return department;
	}


	/**
	 * Set the department of the sales chief
	 * 
	 * @param department location of the sales chief
	 */
	public void setDepartment(String department) {
		this.department = department;
	}


	
	
	/**
	 * Return the string representation of the sales chief.
	 * 
	 * @return a string representation of the sales chief
	 */
	@Override
	public String toString() {
		// Call parent class's toString() method
		return "Sales Chief [super = "+super.toString()+", department= "+getDepartment()+"]";
	}
	
	
	

}
