import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
/**
 * <p>
 * <b>File name:</b> CarBrandsList.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Assignment 3
 *</p>
 * 
 *<p>
 *<b>Date:</b> December 04, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> Arrays of car brands are given to perform some operations like
 * adding to LinkedLists, change elements in LinkedLists to uppercase letters,
 * deleting elements in LinkedLists, reverse LinkedLists, sort LinkedLists and 
 * removing duplicate elements in LinkedLists.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class CarBrandsList {
	/**
	 * This is the entry point for the application. In the main method, methods are 
	 * called to perform operations of the LinkedLists and Arrays.
	 * 
	 * @param args Command line arguments are not used by this program.
	 *
	 */

	public static void main(String[] args) {
		// add rides to list1
		String[] rides = { "cardillac", "toyota", "suzuki", "chevrolet", "hyundai", "mercedies", "keke" };
		List<String> listRides = Arrays.asList(rides);
		LinkedList<String> list1 = new LinkedList<String>(listRides);

		// add rides2 to list2
		String[] rides2 = { "volvo", "subaru", "volkswagen", "nissan", "cardillac", "toyota", "honda" };
		List<String> listRides2 = Arrays.asList(rides2);
		LinkedList<String> list2 = new LinkedList<String>(listRides2);

		// add the elements in list2 to list1 using the addAll method.
		list1.addAll(list2);
		// print out the updated content of list1
		System.out.println("List is: ");
		printList(list1);

		// release list2 resource
		list2 = null;

		// convert all the elements in list1 to uppercase and print out.
		System.out.printf("%nThis is showing the Car Brands in uppercase letters...");
		System.out.printf("%nList is: ");
		toUppercase(list1);
		printList(list1);

		// delete car brands (in positions) 5 to 7 from the list
		System.out.printf("%nDeleting car brands 5 to 7...");
		System.out.printf("%nDeleted car list is: ");
		clearSublist(list1);

		// print out the updated output
		System.out.printf("%nHere is the current list of car brands...");
		System.out.printf("%nList is: ");
		printList(list1);

		// print the current list in reverse order
		System.out.printf("%nReversed List:%n");
		printReversedList(list1);

		// Print the list to show alphabetical order
		System.out.printf("%nSorted car brands in alphabetical order...");
		System.out.printf("%nList is: ");
		Collections.sort(list1);
		printList(list1);
		
		// Remove delicate car brands
		System.out.printf("%nRemoving duplicate car brands...");
		System.out.printf("%nNon-duplicates are: ");
		printNonDuplicates(list1);

	}

	
	
	/**
	 * method to print each element in the LinkedList
	 * 
	 * @param list The linkedList needs to be printed
	 * */ 
	public static void printList(LinkedList<String> list) {
		// use Iterator.hasNext() to get each element
		Iterator<String> iterator = list.iterator();
		while(iterator.hasNext()) {
			  System.out.printf("%s ",iterator.next());
			}
		System.out.println();
	}
	
	
	/**
	 * method to change elements in LinkedList to uppercase letters
	 * 
	 * @param list The linkedList needs to be performed
	 * @return LinkedList after change
	 * */ 
	public static LinkedList<String> toUppercase(LinkedList<String> list) {
		// use for loop and LinkedList.get()to get each element
		for (int i = 0; i < list.size(); i++) {
			list.set(i, list.get(i).toUpperCase());
		}
		return list;
	}

	
	
	/**
	 * method to get the sublist. After print out the sublist, it 
	 * is removed from the original list and then, the sublist is
	 * cleared.
	 * 
	 * @param list The linkedList needs to be performed
	 * */ 
	private static void clearSublist(LinkedList<String> list) {

		LinkedList<String> sublist = new LinkedList<String>(list.subList(5, 8));
		
		printList(sublist);
		
		// use clear method to delete sublist items
		list.subList(5, 8).clear();
	}

	
	/**
	 * method to print the LinkedList in reverse order
	 * 
	 * @param list The linkedList needs to be printed
	 * */ 
	public static void printReversedList(LinkedList<String> list) {
		LinkedList<String> tempList = new LinkedList<String>();
		for (int i = list.size() - 1; i >= 0; i--) {
			tempList.add(list.get(i));
		}
		printList(tempList);
	}

	
	
	/**
	 * method to print the LinkedList without duplicates
	 * 
	 * @param list The linkedList needs to be performed
	 * */ 
	public static void printNonDuplicates(LinkedList<String> list) {
		Set<String> carSet = new HashSet<String>();
		carSet.addAll(list);
		list.clear();
		list.addAll(carSet);
		printList(list);
	}

}
