
/**
 * <p>
 * <b>File name:</b> TestDemo.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 4
 *</p>
 * 
 *<p>
 *<b>Date:</b> October 13, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to test recordPurchase() method in YourPurchases.java. 
 * This test should pass without errors.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

import org.junit.Assert;
import org.junit.Test;

public class YourPurchasesTest {
	// EPSILON is used to verify the difference between the expected value and the return value
	private static final double EPSILON = 1E-12;

	@Test
	public void twoPurchases() {
		YourPurchases register = new YourPurchases();
		register.recordPurchase(0.75);
		register.recordPurchase(1.50);
		register.receivePayment(2, 0, 5, 0, 0);
		double expected = 0.25;
		Assert.assertEquals(expected, register.giveChange(), EPSILON);
	}

}
