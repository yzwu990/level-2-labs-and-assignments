
/**
 * <p>
 * <b>File name:</b> TestDemo.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 4
 *</p>
 * 
 *<p>
 *<b>Date:</b> October 13, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to test method calculateChange() in YourPurchases.java. 
 * This test should fail with errors.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

import org.junit.Assert;
import org.junit.Test;

public class YourPurchasesTest2 {
	// EPSILON is used to verify the difference between the expected value and the return value
	private static final double EPSILON = 1E-12;

	// Test calculateChange() with 1 parameter

	@Test
	public void testCalculateChange() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(1.5);
		aPurchase.receivePayment(5, 0, 0, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 3.50;
		Assert.assertEquals(expected, changeResult, EPSILON);

	}

	// Test calculateChange() with 2 parameters
	@Test
	public void testCalculateChange2() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(6.2);
		aPurchase.receivePayment(5, 5, 0, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 0.05;
		Assert.assertEquals(expected, changeResult, EPSILON);

	}

	// Test calculateChange() with 3 parameters
	@Test
	public void testCalculateChange3() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(4.5);
		aPurchase.receivePayment(3, 5, 4, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 0.15;
		Assert.assertEquals(expected, changeResult, EPSILON);

	}

	// Test calculateChange() with 4 parameters
	@Test
	public void testCalculateChange4() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(7.1);
		aPurchase.receivePayment(6, 3, 5, 9, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 0.6;
		Assert.assertEquals(expected, changeResult, EPSILON);

	}

	// Test calculateChange() with 5 parameters
	@Test
	public void testCalculateChange5() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(11.34);
		aPurchase.receivePayment(8, 6, 10, 15, 10);
		double changeResult = aPurchase.CalculateChange();
		double expected = 0.01;
		Assert.assertEquals(expected, changeResult, EPSILON);

	}

}
