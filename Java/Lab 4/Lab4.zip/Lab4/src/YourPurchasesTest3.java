
/**
 * <p>
 * <b>File name:</b> TestDemo.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 4
 *</p>
 * 
 *<p>
 *<b>Date:</b> October 13, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to test every method in YourPurchases.java. 
 * Method calculateChange() should fail with errors.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

import org.junit.Assert;
import org.junit.Test;

public class YourPurchasesTest3 {
	// EPSILON is used to verify the difference between the expected value and the return value
	private static final double EPSILON = 1E-12;

	// Test getPurchase()
	@Test
	public void testGetPurchase() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(1);
		double purchase = aPurchase.getPurchase();
		double expected = 1;
		Assert.assertEquals(expected, purchase, EPSILON);
	}

	// Test getPayment()
	@Test
	public void testGetPayment() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.receivePayment(1, 0, 0, 0, 0);
		double payment = aPurchase.getPayment();
		double expected = 1;
		Assert.assertEquals(expected, payment, EPSILON);
	}

	// Test recordPurchase()
	@Test
	public void testRecordPurchase() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(1);
		aPurchase.recordPurchase(0.5);
		aPurchase.recordPurchase(0.05);
		double purchase = aPurchase.getPurchase();
		double expected = 1.55;
		Assert.assertEquals(expected, purchase, EPSILON);
	}

	// Test ReceivePayment()
	@Test
	public void testReceivePayment() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.receivePayment(5, 5, 0, 0, 0);
		double payment = aPurchase.getPayment();
		double expected = 6.25;
		Assert.assertEquals(expected, payment, EPSILON);

	}

	// Test claculateChange()
	@Test
	public void testCalculateChange() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(6.2);
		aPurchase.receivePayment(5, 5, 0, 0, 0);
		double changeResult = aPurchase.CalculateChange();
		double expected = 0.05;
		Assert.assertEquals(expected, changeResult, EPSILON);

	}

	// Test giveChange()
	@Test
	public void testGiveChange() {
		YourPurchases aPurchase = new YourPurchases();
		aPurchase.recordPurchase(6.2);
		aPurchase.receivePayment(5, 5, 0, 0, 0);
		double giveChange = aPurchase.giveChange();
		double expected = 0.05;
		Assert.assertEquals(expected, giveChange, EPSILON);

	}

}
