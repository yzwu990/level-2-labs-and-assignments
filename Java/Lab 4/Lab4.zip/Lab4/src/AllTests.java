
/**
 * <p>
 * <b>File name:</b> TestDemo.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 4
 *</p>
 * 
 *<p>
 *<b>Date:</b> October 13, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This is a JUnit Test Suite. 
 *It includes YourPurchasesTest.class,YourPurchasesTest2.class, and YourPurchasesTest3.class
 *
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */


import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ YourPurchasesTest.class, YourPurchasesTest2.class, YourPurchasesTest3.class })
public class AllTests {

}
