
/**
 * <p>
 * <b>File name:</b> TestDemo.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 *         <p>
 *         <b>Class:</b> CST8284 Section 312
 *         </p>
 * 
 *         <p>
 *         <b>Assignment:</b> Lab 2
 *         </p>
 * 
 *         <p>
 *         <b>Date:</b> Sept 30, 2022
 *         </p>
 * 
 *         <p>
 *         <b>Professor:</b> Fedor Ilitchev
 *         </p>
 * 
 *         <hr>
 * 
 *         <p>
 *         <b>Purpose:</b> This is the driver class for this program. This means that it just runs the application with a method main.
 *         This class is used to test constructor chain.
 *         
 *          <hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 */


public class TestDemo {

	/**
	 * This is the entry point for the application, it instantiates 4 EventSchedule
	 * objects to show-case the constructors. Anonymous objects are used and each
	 * one is only retained long enough to call method create report on each. No
	 * variable names were used, just new Constructor().methodCall().
	 * 
	 * @param args Command line arguments are not used by this program.
	 * 
	 */


	public static void main(String[] args) {

		// constructor without arguments
		EventSchedule event = new EventSchedule();
		System.out.println(event.createReport());
		
		// constructor with int year
		EventSchedule eventYear = new EventSchedule(2023);
		System.out.println(eventYear.createReport());

		// constructor with int year, int month
		EventSchedule eventYearMonth = new EventSchedule(2023, 12);
		System.out.println(eventYearMonth.createReport());

		// constructor with int year, int month, int day
		EventSchedule eventYearMonthDate = new EventSchedule(2023, 12, 15);
		System.out.println(eventYearMonthDate.createReport());


	}

}
