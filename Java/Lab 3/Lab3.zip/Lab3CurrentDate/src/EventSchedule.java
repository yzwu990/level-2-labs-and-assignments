import java.util.Calendar;

/**
 * <p>
 * <b>File name:</b> TestDemo.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 *         <p>
 *         <b>Class:</b> CST8284 Section 312
 *         </p>
 * 
 *         <p>
 *         <b>Assignment:</b> Lab 2
 *         </p>
 * 
 *         <p>
 *         <b>Date:</b> Sept 30, 2022
 *         </p>
 * 
 *         <p>
 *         <b>Professor:</b> Fedor Ilitchev
 *         </p>
 * 
 *         <hr>
 * 
 *         <p>
 *         <b>Purpose:</b> This class is named EventSchedule Class. It shows constructor chaining using keyword "this".
 *         
 *         <hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */


public class EventSchedule {

	/*
	 * year component of the date of EventSchedule.
	 */
	private int year;
	
	/*
	 * month component of the date of EventSchedule
	 */
	private int month;
	
	/*
	 * day component of the date of EventSchedule
	 */
	private int day;
	
	
	/*
	 * use Class Calendar to get current year, month and day 
	 * 
	 */
	private static Calendar calendar = Calendar.getInstance();
	
	
	
	/**
	 * The default constructor sets year, month, day to the current date.
	 */
	public EventSchedule() {
		this(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH)+1, calendar.get(Calendar.DATE));
		System.out.println("EventSchedule() was called");
	
	}
	
	/**
	 * This constructor sets the year as passed, month to current month,
	 * and day to current day.
	 * @param year The year of this EventSchedule.
	 */
	
	public EventSchedule(int year) {
		this(year, calendar.get(Calendar.MONTH)+1, calendar.get(Calendar.DATE));
		System.out.println("EventSchedule(int) was called");
	}
	
	
	/**
	 * This constructor sets the year as passed, month as passed,
	 * and day to current day.
	 * @param year The year of this EventSchedule.
	 * @param month The month of this EventSchedule.
	 */	

	public EventSchedule(int year, int month) {
		this(year, month, calendar.get(Calendar.DATE));
		System.out.println("EventSchedule(int, int) was called");
	}
	
	

	/**
	 * This constructor sets the year as passed, month as passed, and
	 * day as passed.
	 * @param year The year of this EventSchedule.
	 * @param month The month of this EventSchedule.
	 * @param day The day of this EventSchedule.
	 */
	
	
	public EventSchedule(int year, int month, int day) {
		System.out.println("EventSchedule(int, int, int) was called");
		this.year =year;
		this.month = month;
		this.day = day;
	}
	
	
	/**
	 * Returns the year for this EventSchedule.
	 * @return the year for this EventSchedule.
	 */
	public int getYear() {
		return year;
	}
	/**
	 * Sets the year for this EventSchedule.
	 * @param year The year for this EventSchedule.
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * Returns the month for this EventSchedule.
	 * @return month The month for this EventSchedule.
	 */
	public int getMonth() {
		return month;
	}
	/**
	 * Sets the month state for this EventSchedule.
	 * @param month This is the month to set for EventSchedule.
	 */
	
	public void setMonth(int month) {
		this.month = month;
	}
	
	
	/**
	 * Returns day of this EventSchedule.
	 * @return day of this EventSchedule.
	 */
	public double getDay() {
		return day;
	}
	/**
	 * Sets the day of this EventSchedule.
	 * @param day The day of this EventSchedule .
	 */
	public void setDay(int day) {
		this.day = day;
	}
	
	/**
	 * @return A String representation of this EventSchedule, each field is separated 
	 * by a comma in the order of year, month, day
	 */
	public String createReport() {
		return String.format("EventSchedule, " + "year: %d, Month: %d, Day: %d%n",year,month,day);
	}
}
