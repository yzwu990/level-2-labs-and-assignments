/**
 * <p>
 * <b>File name:</b> CommissionProgrammer.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a CommissionProgrammer object.
 *BasePlusCommissionProgrammer class extends class Programmer.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */


public class CommissionProgrammer extends Programmer {

	private double grossSales; // gross weekly sales
	private double commissionRate; // commission percentage

	/**
	 * Constructor with arguments.
	 * 
	 * @param firstName first name
	 * @param lastName last name
	 * @param socialSecurityNumber social security number
	 * @param month month
	 * @param year year
	 * @param grossSales gross sales amount
	 * @param commissionRate commission rate of the programmer 
	 * 
	 */
	public CommissionProgrammer(String firstName, String lastName, String socialSecurityNumber, int month, int year,
			double grossSales, double commissionRate) {
		
		// call constructor of parent class
		super(firstName, lastName, socialSecurityNumber);
		
		if (commissionRate <= 0.0 || commissionRate >= 1.0) { // validate
			throw new IllegalArgumentException("Commission rate must be > 0.0 and < 1.0");
		}

		if (grossSales < 0.0) { // validate
			throw new IllegalArgumentException("Gross sales must be >= 0.0");
		}

		this.grossSales = grossSales;
		this.commissionRate = commissionRate;
	}

	
	/**
	 * Set gross sales amount
	 *
	 * @param grossSales gross sales amount
	 */
	public void setGrossSales(double grossSales) {
		if (grossSales < 0.0) { // validate
			throw new IllegalArgumentException("Gross sales must be >= 0.0");
		}

		this.grossSales = grossSales;
	}

	
	/**
	 * Return gross sales amount
	 *
	 * @return gross sales amount
	 */
	public double getGrossSales() {
		return grossSales;
	}

	/**
	 * Set commission rate
	 *
	 * @param commissionRate commission rate
	 */
	public void setCommissionRate(double commissionRate) {
		if (commissionRate <= 0.0 || commissionRate >= 1.0) { // validate
			throw new IllegalArgumentException("Commission rate must be > 0.0 and < 1.0");
		}

		this.commissionRate = commissionRate;
	}

	
	/**
	 * Return commission rate
	 *
	 * @return commission rate
	 */
	public double getCommissionRate() {
		return commissionRate;
	}

	
	/**
	 * Calculate payment amount
	 *
	 * @return payment due
	 */
	@Override
	public double getPaymentAmount() {
		return getCommissionRate() * getGrossSales();
	}
	

	/**
	 * Return string representation of CommissionProgrammer object
	 *
	 * @return string representation of CommissionProgrammer object
	 */
	@Override
	public String toString() {

		return String.format("%s: ", "commission programmer") + super.toString() + String.format(
				"\n%s: $%,.2f; %s: %.2f", "gross sales", getGrossSales(), "commission rate", getCommissionRate());

	}

}
