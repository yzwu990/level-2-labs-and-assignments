/**
 * <p>
 * <b>File name:</b> Invoice.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create an invoice object.
 *Invoice class implements Payme interface.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class Invoice implements Payme {

	private String partNumber;
	private String partDescription;
	private int quantity;
	private double pricePerItem;

	
	/**
	 * Constructor with arguments.
	 * 
	 * @param part part number
	 * @param description part description
	 * @param count part quantity
	 * @param price part price
	 * 
	 */
	public Invoice(String part, String description, int count, double price) {
		partNumber = part;
		partDescription = description;
		setQuantity(count); // validate and store quantity
		setPricePerItem(price); // validate and store price per item
	}

	
	/**
	 * Set part number
	 *
	 * @param part part number
	 */
	public void setPartNumber(String part) {
		partNumber = part; // should validate
	}

	
	/**
	 * Get part number
	 *
	 * @return part number
	 */
	public String getPartNumber() {
		return partNumber;
	}

	
	/**
	 * Set part description
	 *
	 * @param description part description
	 */
	public void setPartDescription(String description) {
		partDescription = description; // should validate
	}

	
	/**
	 * Get part description
	 *
	 * @return part description
	 */
	public String getPartDescription() {
		return partDescription;
	}

	
	/**
	 * Set part quantity
	 *
	 * @param count part quantity
	 */
	public void setQuantity(int count) {
		quantity = (count < 0) ? 0 : count; // quantity cannot be negative
	}

	
	/**
	 * Get part quantity
	 *
	 * @return part quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	
	/**
	 * Set part price
	 *
	 * @param price part price
	 */
	public void setPricePerItem(double price) {
		pricePerItem = (price < 0.0) ? 0.0 : price; // validate price
	}

	
	/**
	 * Get part price
	 *
	 * @return part price
	 */
	public double getPricePerItem() {
		return pricePerItem;
	}

	
	/**
	 * Return string representation of Invoice object
	 *
	 * @return string representation of Invoice object
	 */
	@Override
	public String toString() {
		return String.format("%s: \n%s: %s (%s) \n%s: %d \n%s: $%,.2f", "invoice", "part number", getPartNumber(),
				getPartDescription(), "quantity", getQuantity(), "price per item", getPricePerItem());
	}
	
	
	/**
	 * Calculate payment amount
	 *
	 * @return payment due
	 */
	@Override
	public double getPaymentAmount() {
		return getQuantity() * getPricePerItem(); // calculate total cost
	}
}
