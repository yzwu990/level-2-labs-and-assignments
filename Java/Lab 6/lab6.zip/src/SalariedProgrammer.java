/**
 * <p>
 * <b>File name:</b> SalariedProgrammer.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a SalariedProgrammer object.
 *SalariedProgrammer class extends class Programmer.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */
public class SalariedProgrammer extends Programmer {
	private double weeklySalary;


	/**
	 * Constructor with arguments.
	 * 
	 * @param firstName first name
	 * @param lastName last name
	 * @param socialSecurityNumber social security number
	 * @param month month
	 * @param year year
	 * @param weeklySalary weekly salary
	 * 
	 */
	public SalariedProgrammer(String firstName, String lastName, String socialSecurityNumber, int month, int year,
			double weeklySalary) {
		super(firstName, lastName, socialSecurityNumber);

		if (weeklySalary < 0.0) {
			throw new IllegalArgumentException("Weekly salary must be >= 0.0");
		}

		this.weeklySalary = weeklySalary;
	}

	
	/**
	 * Set weekly salary
	 *
	 * @param weeklySalary weekly salary
	 */
	public void setWeeklySalary(double weeklySalary) {
		if (weeklySalary < 0.0) {
			throw new IllegalArgumentException("Weekly salary must be >= 0.0");
		}

		this.weeklySalary = weeklySalary;
	}

	
	/**
	 * Return weekly salary
	 *
	 * @return weekly salary
	 */
	public double getWeeklySalary() {
		return weeklySalary;
	}

	
	
	/**
	 * Calculate payment amount
	 *
	 * @return payment due
	 */
	@Override
	public double getPaymentAmount() {
		return getWeeklySalary();
	}

	
	/**
	 * Return string representation of SalariedProgrammer object
	 *
	 * @return string representation of SalariedProgrammer object
	 */  
	@Override
	public String toString() {

		return String.format("%s: ", "salaried Programmer") + super.toString()
				+ String.format("\n%s: $%,.2f", "weekly salary", getPaymentAmount());

	}

}
