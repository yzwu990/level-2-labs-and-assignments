
/**
 * <p>
 * <b>File name:</b> Programmer.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This is an abstract superclass that IMPLEMENTS the Payme interface.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public abstract class Programmer implements Payme {

	private String firstName;
	private String lastName;
	private String socialSecurityNumber;

	/**
	 * Constructor with arguments.
	 * 
	 * @param first first name
	 * @param last last name
	 * @param ssn social security number
	 */
	public Programmer(String first, String last, String ssn) {
		firstName = first;
		lastName = last;
		socialSecurityNumber = ssn;
	}

	
	/**
	 * Get first name
	 *
	 * @return first name
	 */
	public String getFirstName() {
		return firstName;
	}

	
	/**
	 * Set first name
	 *
	 * @param firstName first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	/**
	 * Get last name
	 *
	 * @return last name
	 */
	public String getLastName() {
		return lastName;
	}

	
	/**
	 * Set last name
	 *
	 * @param lastName last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	/**
	 * Get social security number
	 *
	 * @return social security number
	 */
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}

	
	/**
	 * Set social security number
	 *
	 * @param socialSecurityNumber social security number
	 */
	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}

	
	/**
	 * Return string representation of Programmer object
	 *
	 * @return string representation of Programmer object
	 */
	@Override
	public String toString() {
		return String.format("%s %s \n%s: %s", getFirstName(), getLastName(), "social security number",
				getSocialSecurityNumber());
	}

}
