/**
 * <p>
 * <b>File name:</b> BasePlusCommissionProgrammer.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a BasePlusCommissionProgrammer object.
 *BasePlusCommissionProgrammer class extends class CommissionProgrammer.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */



public class BasePlusCommissionProgrammer extends CommissionProgrammer {

	private double baseSalary; // base salary per week

	/**
	 * Constructor with arguments.
	 * 
	 * @param firstName first name
	 * @param lastName last name
	 * @param socialSecurityNumber social security number
	 * @param month month
	 * @param year year
	 * @param grossSales gross sales amount
	 * @param commissionRate commission rate of the programmer 
	 * @param baseSalary base salary of the programmer 
	 * 
	 */
	public BasePlusCommissionProgrammer(String firstName, String lastName, String socialSecurityNumber, int month,
			int year, double grossSales, double commissionRate, double baseSalary) {
		
		// call constructor of parent class
		super(firstName, lastName, socialSecurityNumber, month, year, grossSales, commissionRate);

		if (baseSalary < 0.0) { // validate baseSalary
			throw new IllegalArgumentException("Base salary must be >= 0.0");
		}

		this.baseSalary = baseSalary;
	}


	/**
	 * Set base salary
	 *
	 * @param baseSalary base salary of the programmer 
	 */
	public void setBaseSalary(double baseSalary) {
		if (baseSalary < 0.0) { // validate baseSalary
			throw new IllegalArgumentException("Base salary must be >= 0.0");
		}

		this.baseSalary = baseSalary;
	}

	/**
	 * Return base salary
	 *
	 * @return base salary of the programmer 
	 */
	public double getBaseSalary() {
		return baseSalary;
	}

	
	/**
	 * Calculate payment amount
	 *
	 * @return payment due
	 */
	@Override
	public double getPaymentAmount() {
		return getBaseSalary() + super.getPaymentAmount();
	}

	/**
	 * Return string representation of BasePlusCommissionProgrammer object
	 *
	 * @return string representation of BasePlusCommissionProgrammer object
	 */
	public String toString() {
		return String.format("%s ", "base-plus") + super.toString()
				+ String.format("; %s: $%,.2f", "base salary", getBaseSalary());

	}

}
