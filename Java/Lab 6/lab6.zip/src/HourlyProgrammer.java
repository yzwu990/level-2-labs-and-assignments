/**
 * <p>
 * <b>File name:</b> HourlyProgrammer.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to create a HourlyProgrammer object.
 *HourlyProgrammer class extends class Programmer.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class HourlyProgrammer extends Programmer {
	
	private double wage; // wage per hour
	private double hours; // hours worked for week

	/**
	 * Constructor with arguments.
	 * 
	 * @param firstName first name
	 * @param lastName last name
	 * @param socialSecurityNumber social security number
	 * @param month month
	 * @param year year
	 * @param wage wage per hour 
	 * @param hours hours worked
	 * 
	 */
	public HourlyProgrammer(String firstName, String lastName, String socialSecurityNumber, int month, int year,
			double wage, double hours) {
		super(firstName, lastName, socialSecurityNumber);

		if (wage < 0.0) { // validate wage
			throw new IllegalArgumentException("Hourly wage must be >= 0.0");
		}

		if ((hours < 0.0) || (hours > 168.0)) { // validate hours
			throw new IllegalArgumentException("Hours worked must be >= 0.0 and <= 168.0");
		}

		this.wage = wage;
		this.hours = hours;
	}

	/**
	 * Set wage per hour 
	 *
	 * @param wage wage per hour 
	 */
	public void setWage(double wage) {
		if (wage < 0.0) { // validate wage
			throw new IllegalArgumentException("Hourly wage must be >= 0.0");
		}

		this.wage = wage;
	}

	/**
	 * Return wage per hour 
	 *
	 * @return wage per hour 
	 */
	public double getWage() {
		return wage;
	}

	/**
	 * Set hours worked 
	 *
	 * @param hours hours worked 
	 */
	public void setHours(double hours) {
		if ((hours < 0.0) || (hours > 168.0)) { // validate hours
			throw new IllegalArgumentException("Hours worked must be >= 0.0 and <= 168.0");
		}

		this.hours = hours;
	}

	
	/**
	 * Return hours worked 
	 *
	 * @return hours worked 
	 */
	public double getHours() {
		return hours;
	}

	
	/**
	 * Calculate payment amount
	 *
	 * @return payment due
	 */
	@Override
	public double getPaymentAmount() {
		if (getHours() <= 40) { // no overtime
			return getWage() * getHours();
		} else {
			return 40 * getWage() + (getHours() - 40) * getWage() * 1.5;
		}
	}

	
	/**
	 * Return string representation of HourlyProgrammer object
	 *
	 * @return string representation of HourlyProgrammer object
	 */             
	@Override

	public String toString() {

		return String.format("%s: ", "hourly programmer") + super.toString()
				+ String.format("\n%s: $%,.2f; %s: %.2f", "hourly wage", getWage(), "hours worked", getHours());

	}

}
