/**
 * <p>
 * <b>File name:</b> PaymeInterfaceTest.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This class is used to test Payme interface.
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public class PaymeInterfaceTest {

	/**
	 * This is the entry point for the application. It creates a Array and test each element in the array
	 * 
	 * @param args Command line arguments are not used by this program.
	 */
	
	public static void main(String[] args) {

// a Payme array named paymeObjects with six elements
		
		Payme[] paymeObjects = new Payme[6];
	
		paymeObjects[0] = new Invoice("22776", "brakes", 3, 300);
		paymeObjects[1] = new Invoice("33442", "gear", 5, 90.99);
		paymeObjects[2] = new SalariedProgrammer("Chioma", "Chidimma", "345-67-0001",11, 2022, 320);
		paymeObjects[3] = new HourlyProgrammer("Amara", "Chukwu", "234-56-7770", 11, 2022, 18.95, 40);
		paymeObjects[4] = new CommissionProgrammer("Peter", "Goodman", "123-45-6999", 11, 2022, 16500, 0.44);
		paymeObjects[5] = new BasePlusCommissionProgrammer("Yanzhang", "Wu", "102-34-5888", 11, 2022, 1200, 0.04, 720);


		// ouput header
		System.out.println("Payment for Invoices and Programmers are processed polymorphically:\n");

		
		// generically process each element in array paymeObjects
		for (Payme currentPayme : paymeObjects) {
			
			// output string representation of each object
			System.out.printf("%s \n", currentPayme.toString());

			if (currentPayme instanceof BasePlusCommissionProgrammer) {
				// downcast Payme reference to
				// BasePlusCommissioProgrammer reference
				BasePlusCommissionProgrammer programmer = (BasePlusCommissionProgrammer) currentPayme;

				double oldBaseSalary = programmer.getBaseSalary();
				programmer.setBaseSalary(1.10 * oldBaseSalary);
				System.out.printf("new base salary with 10%% increase is: $%,.2f\n", programmer.getBaseSalary());
			}

			// output payment due
			System.out.printf("%s: $%,.2f\n\n", "payment due", currentPayme.getPaymentAmount());

		}
	}
}
