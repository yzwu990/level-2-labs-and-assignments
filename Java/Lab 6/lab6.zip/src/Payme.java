/**
 * <p>
 * <b>File name:</b> Payme.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 * 
 * <p>
 * <b>Class:</b> CST8284 Section 312
 * </p>
 * 
 *<p>
 *<b>Assignment:</b> Lab 6
 *</p>
 * 
 *<p>
 *<b>Date:</b> November 17, 2022
 *</p>
 * 
 *<p>
 *<b>Professor:</b> Fedor Ilitchev
 *</p>
 * 
 *<hr>
 * 
 *<p>
 *<b>Purpose:</b> This is Payme interface which other classes could interact with
 *         
 *<hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 * 
 */

public interface Payme {

	/**
	 * This is the abstract method of calculate total payment.
	 * Class implements interface Payme should rewrite this method
	 * @return payment due
	 * */
	double getPaymentAmount();
	
	
}
