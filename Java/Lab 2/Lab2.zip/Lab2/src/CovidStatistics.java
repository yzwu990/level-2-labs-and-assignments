/**
 * <p>
 * <b>File name:</b> CovidStatistics.java
 * </p>
 * 
 * @author Yanzhang Wu, 41056465
 * 
 *         <p>
 *         <b>Class:</b> CST8284 Section 312
 *         </p>
 * 
 *         <p>
 *         <b>Assignment:</b> Lab 2
 *         </p>
 * 
 *         <p>
 *         <b>Date:</b> Sept 16, 2022
 *         </p>
 * 
 *         <p>
 *         <b>Professor:</b> Fedor Ilitchev
 *         </p>
 * 
 *         <hr>
 * 
 *         <p>
 *         <b>Purpose:</b> This program will output the table in CovidSample.txt
 *         
 *          <hr>
 * 
 * @since 17.0.4.1
 * @version 1.0
 */

public class CovidStatistics {
	/**
	 * This method will output the table in CovidSample.txt
	 * 
	 * @param args arguments passed from command line
	 */
	public static void main(String[] args) {

		// Rows and columns are provided in the template, but they are not used in the codes.
		// final int ROWS = 7;
		// final int COLUMNS = 8;

		int[][] patients = { { 2200, 1100, 1200, 1000, 1015, 2000, 1092, 2204 },
				{ 5020, 6105, 2009, 9047, 1016, 2014, 2708, 2308 }, { 1720, 2406, 3054, 1018, 1023, 3100, 1406, 1502 },
				{ 1490, 2002, 2016, 5008, 2044, 1055, 1607, 2201 }, { 1520, 1007, 1092, 2065, 1023, 1010, 1046, 1502 },
				{ 1670, 1201, 2008, 2001, 1086, 1009, 1041, 1706 }, { 1870, 2001, 2078, 1006, 1053, 1702, 1009, 1406 }

		};

		String[] provinces = { "Ontario", "Quebec", "Nova Scotia", "New Brunswick", "Manitoba", "British Columbia",
				"Prince Edward Island" };

		System.out.println("              Month     Feb    March    April   May     June    July    Aug     Sept");
		System.out.println();
		// call printTable to print the first part of the table
		printTable(patients, provinces);

		System.out.println();
		System.out.printf("%20s", "Recovered Patients");
		// call sumColumn to print the second part of the table
		printSumColumn(patients);

		System.out.println();
		System.out.println();
		System.out.println("               Vaccinate and maintain good health practices!");
	}

	/**
	 * This method iterates and print out each element in the 2D array, and
	 * provinces are formatted and printed out as column.
	 * 
	 * @param patients  2D array of patients
	 * @param provinces array of provinces
	 */
	public static void printTable(int[][] patients, String[] provinces) {
		for (int i = 0; i < patients.length; i++) {// iterate the row
			System.out.printf("%20s", provinces[i]);
			for (int j = 0; j < patients[i].length; j++) {// iterate each element in each row
				System.out.print("\t" + patients[i][j]);
				if (j == patients[i].length - 1) {// go to next row if the element is the last one in one row
					System.out.println();
				}

			}
		}

	}

	/**
	 * This method calculate the sum of each column of the 2D array. The calculation
	 * results are formated and printed out.
	 * 
	 * @param patients 2D array of patients
	 */

	public static void printSumColumn(int[][] patients) {
		// set the sum = 0 before the loop starts
		int sum = 0;
		for (int j = 0; j < patients[0].length; j++) {// iterate the column
			for (int i = 0; i < patients.length; i++) {// iterate each element in each column
				// calculate the sum of elements 
				sum += patients[i][j];
				// go to next column if the element is the last one in one column,
				// and set sum = 0
				if (i == patients.length - 1) {
					System.out.printf("\t" + sum);
					sum = 0;
				}
			}
		}
	}

}