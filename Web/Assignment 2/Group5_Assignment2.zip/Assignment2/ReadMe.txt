Instruction:

Step 1. Run warehouse.sql in sqlScript folder.

Step 2. Set $servername $server_username and $server_password 
	  in backend/connect.php before use.